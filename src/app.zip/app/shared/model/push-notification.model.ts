export interface PushDevice {
    registrationId: string;
    registrationType: string;
}
