export interface PreferredGiftCards {
    GiftCardTypeID: number;
    GiftCardProvider: string;
}
