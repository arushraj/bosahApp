export interface UserReligion {
    ReligionId: number;
    Religion: string;
}
