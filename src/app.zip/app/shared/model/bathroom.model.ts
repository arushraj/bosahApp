export interface Bathroom {
    BathroomID: number;
    BathRoomType: string;
}
