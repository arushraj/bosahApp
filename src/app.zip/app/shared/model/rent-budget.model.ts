export interface RentBudget {
    RentBudgetID: number;
    RentBudgetType: string;
}
