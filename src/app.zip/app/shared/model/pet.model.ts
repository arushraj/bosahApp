export interface Pet {
    PetId: number;
    PetName: string;
}
