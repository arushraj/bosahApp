export interface Bedroom {
    BedroomID: number;
    BedroomType: string;
}
