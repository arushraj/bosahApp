export interface Drinking {
    Id: number;
    Details: string;
}
