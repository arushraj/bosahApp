export interface Smoking {
    Id: number;
    Details: string;
}
