export interface UserLocation {
    CityId: number;
    City: string;
}
