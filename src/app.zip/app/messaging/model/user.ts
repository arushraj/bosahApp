export interface OnlineUser {
    isOnline?: boolean;
    isTyping?: boolean;
    lastOnlineDateTime?: string;
}
